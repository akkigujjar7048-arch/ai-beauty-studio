# AI Beauty Studio — Starter Website

A responsive, client-side beauty shade finder demo.

## Run it
- Open `index.html` in a browser for manual profile and product recommendations.
- For camera access, serve the folder on HTTPS or localhost (camera permissions are restricted on ordinary `file://` pages).
- Simple local server: `python -m http.server 8000`, then visit `http://localhost:8000`.

## Included
- Luxury pink & white responsive UI
- Camera capture and image upload
- Approximate browser-side pixel estimate (lighting-sensitive; not a validated skin analysis model)
- Manual skin depth, undertone, skin type and look selection
- Dynamic product shade-family suggestions
- Step-by-step makeup instructions and quantity starting points
- No photo upload or server storage in this demo

## Important limitations before launch
This is a working frontend prototype, not a production-grade AI skin analysis service. Camera pixel sampling is only a rough demo and can be inaccurate due to lighting, white balance, filters, exposure, makeup and device differences. Always let users correct the estimate manually. Do not claim medical diagnosis or guaranteed shade matching.

For production:
1. Replace the pixel heuristic with a tested face/skin-region analysis model and evaluate across varied lighting, devices and skin tones.
2. Add a product catalogue with verified brand shade names, ingredients, prices and retailer links; keep recommendations transparent and sponsored placements labelled.
3. Add consent, privacy policy, retention/deletion controls and secure backend only if truly needed. Avoid storing face photos by default.
4. Add accessibility, security headers, error handling, analytics consent and cross-device QA.
5. Do not make beauty recommendations that shame, rank or imply a user's natural skin tone needs correction.
